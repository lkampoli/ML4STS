# VV' down
#python3 libreconverter.py kvvs_down_n2_no.xlsx  kvvs_down_n2_no-%s.csv
#python3 libreconverter.py kvvs_down_n2_o2.xlsx  kvvs_down_n2_o2-%s.csv
#python3 libreconverter.py kvvs_down_no_n2.xlsx  kvvs_down_no_n2-%s.csv
#python3 libreconverter.py kvvs_down_no_o2.xlsx  kvvs_down_no_o2-%s.csv
#python3 libreconverter.py kvvs_down_o2_n2.xlsx  kvvs_down_o2_n2-%s.csv
#python3 libreconverter.py kvvs_down_o2_no.xlsx  kvvs_down_o2_no-%s.csv
# VV' up
#python3 libreconverter.py kvvs_up_n2_no.xlsx    kvvs_up_n2_no-%s.csv
#python3 libreconverter.py kvvs_up_n2_o2.xlsx    kvvs_up_n2_o2-%s.csv
#python3 libreconverter.py kvvs_up_no_n2.xlsx    kvvs_up_no_n2-%s.csv
#python3 libreconverter.py kvvs_up_no_o2.xlsx    kvvs_up_no_o2-%s.csv
#python3 libreconverter.py kvvs_up_o2_n2.xlsx    kvvs_up_o2_n2-%s.csv
#python3 libreconverter.py kvvs_up_o2_no.xlsx    kvvs_up_o2_no-%s.csv
# VT
#python3 libreconverter.py VT_RATES.xlsx         VT_RATES-%s.csv
# exchange (Zeldovich)
#python3 libreconverter.py ZR_N2_RATES.xlsx      ZR_N2_RATES-%s.csv
#python3 libreconverter.py ZR_O2_RATES.xlsx 	  ZR_O2_RATES-%s.csv
# dissociation/recombination
#python3 libreconverter.py DR_RATES.xlsx 	  DR_RATES-%s.csv
# VV down
#python3 libreconverter.py VV_DOWN_N2_RATES.xlsx VV_DOWN_N2_RATES-%s.csv
#python3 libreconverter.py VV_DOWN_NO_RATES.xlsx VV_DOWN_NO_RATES-%s.csv
#python3 libreconverter.py VV_DOWN_O2_RATES.xlsx VV_DOWN_O2_RATES-%s.csv
# VV up
#python3 libreconverter.py VV_UP_N2_RATES.xlsx   VV_UP_N2_RATES-%s.csv
#python3 libreconverter.py VV_UP_NO_RATES.xlsx   VV_UP_NO_RATES-%s.csv
python3 libreconverter.py VV_UP_O2_RATES.xlsx   VV_UP_O2_RATES-%s.csv
